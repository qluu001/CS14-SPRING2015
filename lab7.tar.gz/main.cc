//Name: Quocviet Luu
//SID: 861178020
//Date: 05/25/2015
//Approach:
//1) Used fstream to to create a vector from the provided words.txt
//2) Shuffle data using 2 for loops and with a swap and random function
//3) For loop to test inserting value at 50000, then resize the vector
//   by -5000 until all test cases between 50000 to 5000 are handled
//4) Write to file data.txt
//5) Plot the data





#include <iostream>
#include <fstream>
#include <vector>
#include <cstdlib>
#include <ctime>
#include <chrono>
#include <set>
#include <unordered_set>

using namespace std;


void shuffleData(vector<string> &v)
{
    srand(time(NULL));
    for(int m = 0; m < 50; ++m)
    {
        for(unsigned i = 0; i < v.size(); ++i)
        {
            std::swap(v.at(i), v.at(rand() % v.size()));
        }
    }
}

double insertSet(std::vector<string> &v )
{
    double averageTime = 0;
    for(int i = 0; i < 10; ++i)
    {
        shuffleData(v);
        std::set<string> s;
        auto t1 = std::chrono::high_resolution_clock::now();
        for(unsigned k = 0; k < v.size(); ++k)
        {
            s.insert(v.at(k));
        }
        auto t2 = std::chrono::high_resolution_clock::now();
        using Fpseconds = 
        std::chrono::duration<float, std::chrono::milliseconds::period>;
 
        static_assert(std::chrono::treat_as_floating_point<Fpseconds::rep>::value, 
                  "Rep required to be floating point");
        
        
        //cout << Fpseconds(t2 - t1).count() << endl;
        averageTime = averageTime + Fpseconds(t2 - t1).count();
    }
    averageTime /= 10;
    //cout <<"Insert time set: " << averageTime << " milliseconds" << endl;
    //cout << "Query time set: " << averageTime/v.size() << " milliseconds" << endl;
    return averageTime;
}

double insertUnordered(std::vector<string> &v)
{
    double averageTime = 0;
    for(unsigned i = 0; i < 10; ++i)
    {
        shuffleData(v);
        std::unordered_set<string> s;
        auto t1 = std::chrono::high_resolution_clock::now();
        for(unsigned k = 0; k < v.size(); ++k)
        {
            s.insert(v.at(k));
        }
        auto t2 = std::chrono::high_resolution_clock::now();
        using Fpseconds = 
        std::chrono::duration<float, std::chrono::milliseconds::period>;
 
        static_assert(std::chrono::treat_as_floating_point<Fpseconds::rep>::value, 
                  "Rep required to be floating point");
        
        
        //cout << Fpseconds(t2 - t1).count() << endl;
        averageTime = averageTime + Fpseconds(t2 - t1).count();
    }
    averageTime /= 10;
    //cout <<"Insert time unordered_set: " << averageTime << " milliseconds" << endl;
    //cout << "Query time unordered_set: " << averageTime/v.size() << " milliseconds" << endl;
    return averageTime;
}



int main()
{
    vector<string> v;
    ifstream myfile;
    myfile.open("words.txt");
    string s;
    while(myfile >> s)
    {
        v.push_back(s);
    }
    myfile.close();
    
    shuffleData(v);
    
    ofstream datafile;
    datafile.open("data.txt");
    
    
    for(int i = 50000; i >= 5000 ; i -= 5000)
    {
        v.resize(i);
        datafile << v.size() << " ";
        double tree = insertSet(v);
        double hash = insertUnordered(v);
        datafile << tree << " " << hash << " " << tree/v.size() 
        << " " << hash/v.size() << endl;
        
    }
    
    
    
    return 0;
}


//Trees
//Advantages
    //faster than o(n) implementation
    //all elements are sorted in a order

//Disadvantages
    //Slower than hash implementation
    //has log(n) complexicity
    //as more elements are inserted its gets slower at a 
    //increasing rate
    


//Hash tables
//Advantages
    //Faster than the tree
    //o(1) insertion and lookup

//Disadvantages
    //Worst case is 0(n)
    //not sorted
    
    
//A compariable data structure would be unsorted linked
//list. Insert and lookup complexicity is o(1) while it is 
//not sorted. Very similar to hash tables