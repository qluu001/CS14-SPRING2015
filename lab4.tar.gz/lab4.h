//------------------------------------------------------
//Name: Quocviet Luu
//SID: 861178020
//Date: 5/4/2014
//---------------------------------------------------

#include <iostream>
#include <queue>
#include <utility>
#include <stack>

using namespace std;

typedef pair<int,int> Entry;



void preorderRecursion(int m, int n, int k)
{
    //base case used in all functions to return
    //all coprimes added together has to be less than the argument int k
    if(k <= (m + n)) return;
    cout << m << " " << n << endl;
    //each "node" has 3 children
    preorderRecursion((2 * m) - n, m, k);
    preorderRecursion((2 * m) + n, m, k);
    preorderRecursion(m + (2 * n), n, k);
    return;
}

void preorderPrint(int k)
{
    cout << "pre-order" << endl;
    //(2, 1) and (3, 1) are exactly the first 2 coprimes
    preorderRecursion(2, 1, k);
    preorderRecursion(3, 1, k);
}

void postorderRecursion(int m, int n, int k)
{
    if(k <= (m + n)) return;
    postorderRecursion((2 * m) - n, m, k);
    postorderRecursion((2 * m) + n, m, k);
    postorderRecursion(m + (2 * n), n, k);
    cout << m << " " << n << endl;
    return;
}

void postorderPrint(int k)
{
    cout << "post-order" << endl;
    postorderRecursion(2, 1, k);
    postorderRecursion(3, 1, k);
}


void inorderRecursion
(int m, int n, int k, std::priority_queue<pair<int, Entry>> &a)
{
    if(k <= (m + n)) return;
    //basic data type to store the two coprimes
    Entry b(m, n);
    //the pair is used to manipulate the highest priority lookup that...
    //...the priority queue sorts its data
    pair<int, Entry> sum(m + n, b);
    a.push(sum);
    inorderRecursion((2 * m) - n, m, k, a);
    inorderRecursion((2 * m) + n, m, k, a);
    inorderRecursion(m + (2 * n), n, k, a);
    return;
}

void inorderPrint(int k)
{
    std::priority_queue<pair<int, Entry>> a;
    cout << "sorted" << endl;
    //covers first 2 coprimes
    inorderRecursion(2, 1, k, a);
    inorderRecursion(3, 1, k, a);
    //stack used to reverse the priority_queue
    stack<Entry> reverseQueue;
    
    while(a.size() != 0)
    {
        //function used to empty the queue and push the stack
        reverseQueue.push(a.top().second);
        a.pop();
    }
    while(reverseQueue.size() != 0)
    {
        //the actual part where everything is printed
        cout << reverseQueue.top().first << " " 
             << reverseQueue.top().second << endl;
        reverseQueue.pop();
    }
    
}