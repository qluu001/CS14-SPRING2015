//------------------------------------------------------
//Name: Quocviet Luu
//SID: 861178020
//Date: 5/4/2014
//---------------------------------------------------
#include "lab4.h"
#include <stdlib.h>
#include <iostream>

using namespace std;

int main(int argc, char *argv[])
{
    //cout << argc << endl;
    if(argc != 2)
    {
        cout << "Arguments: One integer is required" << endl;
        return 0;
    }
    int k = atoi(argv[1]);
    preorderPrint(k);
    postorderPrint(k);
    inorderPrint(k);
    return 0;
}